#pragma once
#include "Mejores.h"
#include <string>
#include "msclr\marshal_cppstd.h"
#include "StdAfx.h"
#define MAX 100
namespace ejercicio15vectorf {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	Mejores  Vector1;
	int pos=0;
	int posr=0; //Variable universal

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblTamano;
	private: System::Windows::Forms::Label^  lblRegistro;
	private: System::Windows::Forms::Label^  lblNota;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtRegistro;
	private: System::Windows::Forms::TextBox^  txtNota;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnRegistrar;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnOrdenar;
	private: System::Windows::Forms::DataGridView^  grillaOrden;

	protected: 

	protected: 










	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Label^  lblMejores;
	private: System::Windows::Forms::DataGridView^  grillaMejores;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblTamano = (gcnew System::Windows::Forms::Label());
			this->lblRegistro = (gcnew System::Windows::Forms::Label());
			this->lblNota = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtRegistro = (gcnew System::Windows::Forms::TextBox());
			this->txtNota = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnRegistrar = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnOrdenar = (gcnew System::Windows::Forms::Button());
			this->grillaOrden = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->lblMejores = (gcnew System::Windows::Forms::Label());
			this->grillaMejores = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaOrden))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaMejores))->BeginInit();
			this->SuspendLayout();
			// 
			// lblTamano
			// 
			this->lblTamano->AutoSize = true;
			this->lblTamano->Location = System::Drawing::Point(29, 14);
			this->lblTamano->Name = L"lblTamano";
			this->lblTamano->Size = System::Drawing::Size(67, 20);
			this->lblTamano->TabIndex = 0;
			this->lblTamano->Text = L"Tamano";
			// 
			// lblRegistro
			// 
			this->lblRegistro->AutoSize = true;
			this->lblRegistro->Location = System::Drawing::Point(29, 52);
			this->lblRegistro->Name = L"lblRegistro";
			this->lblRegistro->Size = System::Drawing::Size(69, 20);
			this->lblRegistro->TabIndex = 1;
			this->lblRegistro->Text = L"Registro";
			// 
			// lblNota
			// 
			this->lblNota->AutoSize = true;
			this->lblNota->Location = System::Drawing::Point(29, 91);
			this->lblNota->Name = L"lblNota";
			this->lblNota->Size = System::Drawing::Size(43, 20);
			this->lblNota->TabIndex = 2;
			this->lblNota->Text = L"Nota";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(114, 14);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(177, 26);
			this->txtTamano->TabIndex = 3;
			// 
			// txtRegistro
			// 
			this->txtRegistro->Location = System::Drawing::Point(114, 52);
			this->txtRegistro->Name = L"txtRegistro";
			this->txtRegistro->Size = System::Drawing::Size(177, 26);
			this->txtRegistro->TabIndex = 4;
			// 
			// txtNota
			// 
			this->txtNota->Location = System::Drawing::Point(114, 91);
			this->txtNota->Name = L"txtNota";
			this->txtNota->Size = System::Drawing::Size(177, 26);
			this->txtNota->TabIndex = 5;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(321, 7);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(128, 33);
			this->btnDefinir->TabIndex = 6;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnRegistrar
			// 
			this->btnRegistrar->Location = System::Drawing::Point(319, 52);
			this->btnRegistrar->Name = L"btnRegistrar";
			this->btnRegistrar->Size = System::Drawing::Size(130, 33);
			this->btnRegistrar->TabIndex = 7;
			this->btnRegistrar->Text = L"Registrar";
			this->btnRegistrar->UseVisualStyleBackColor = true;
			this->btnRegistrar->Click += gcnew System::EventHandler(this, &Form1::btnRegistrar_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(319, 91);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(129, 35);
			this->btnIngresar->TabIndex = 8;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnOrdenar
			// 
			this->btnOrdenar->Location = System::Drawing::Point(605, 4);
			this->btnOrdenar->Name = L"btnOrdenar";
			this->btnOrdenar->Size = System::Drawing::Size(128, 41);
			this->btnOrdenar->TabIndex = 9;
			this->btnOrdenar->Text = L"Ordenar";
			this->btnOrdenar->UseVisualStyleBackColor = true;
			this->btnOrdenar->Click += gcnew System::EventHandler(this, &Form1::btnOrdenar_Click);
			// 
			// grillaOrden
			// 
			this->grillaOrden->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaOrden->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, 
				this->Column2});
			this->grillaOrden->Location = System::Drawing::Point(14, 144);
			this->grillaOrden->Name = L"grillaOrden";
			this->grillaOrden->RowTemplate->Height = 28;
			this->grillaOrden->Size = System::Drawing::Size(434, 221);
			this->grillaOrden->TabIndex = 10;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Registro";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Nota";
			this->Column2->Name = L"Column2";
			// 
			// lblMejores
			// 
			this->lblMejores->AutoSize = true;
			this->lblMejores->Location = System::Drawing::Point(488, 21);
			this->lblMejores->Name = L"lblMejores";
			this->lblMejores->Size = System::Drawing::Size(100, 20);
			this->lblMejores->TabIndex = 11;
			this->lblMejores->Text = L"Tres mejores";
			// 
			// grillaMejores
			// 
			this->grillaMejores->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaMejores->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column3, 
				this->Column4});
			this->grillaMejores->Location = System::Drawing::Point(494, 50);
			this->grillaMejores->Name = L"grillaMejores";
			this->grillaMejores->RowTemplate->Height = 28;
			this->grillaMejores->Size = System::Drawing::Size(384, 185);
			this->grillaMejores->TabIndex = 12;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Registro";
			this->Column3->Name = L"Column3";
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"Nota";
			this->Column4->Name = L"Column4";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(890, 377);
			this->Controls->Add(this->grillaMejores);
			this->Controls->Add(this->lblMejores);
			this->Controls->Add(this->grillaOrden);
			this->Controls->Add(this->btnOrdenar);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnRegistrar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtNota);
			this->Controls->Add(this->txtRegistro);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->lblNota);
			this->Controls->Add(this->lblRegistro);
			this->Controls->Add(this->lblTamano);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaOrden))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaMejores))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=System::Convert::ToInt32(txtTamano->Text);
			 Vector1.Set_tamano(tam);
			 grillaOrden->RowCount=Vector1.Get_tamano();
			 grillaMejores->RowCount=3;
			 pos=0;
		 }
private: System::Void btnRegistrar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int registro;
			 int elem;
			 elem=System::Convert::ToInt32(txtRegistro->Text);
			 if(Vector1.InsertarReg(elem,posr))
			 {posr++;
			 grillaOrden->ColumnCount=2;
			 grillaOrden->RowCount=Vector1.Get_tamano();
			 for(int i=0;i<Vector1.Get_tamano();i++)
			 {registro=Vector1.Get_Registro(i);
			  grillaOrden->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(registro);
			  

			 }
			 }
		 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int nota;
			 int elem;

			 elem=System::Convert::ToInt32(txtNota->Text);
			 if(Vector1.Insertar(elem,pos))
			 {pos++;
			 grillaOrden->ColumnCount=2;
			 grillaOrden->RowCount=Vector1.Get_tamano();

			 for(int i=0;i<Vector1.Get_tamano();i++)
			 {nota=Vector1.Get_vector(i);
			  grillaOrden->Rows[i]->Cells[1]->Value=System::Convert::ToInt32(nota);
			 }
			 }
		 }	 
private: System::Void btnOrdenar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int nota,registro;
			 Vector1.ordenar();
			 for(int i=0;i<3;i++)
			 {nota=Vector1.Get_vector(i);
			  grillaMejores->Rows[i]->Cells[1]->Value=System::Convert::ToInt32(nota);
			 }
			 for(int i=0;i<3;i++)
			 {registro=Vector1.Get_Registro(i);
			  grillaMejores->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(registro);
			 }
		 }
};
}

