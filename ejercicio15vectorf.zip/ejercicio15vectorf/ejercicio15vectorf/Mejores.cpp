#include "StdAfx.h"
#include "Mejores.h"
#include <string>
#define MAX 100

Mejores::Mejores(void)
{  nota[MAX]=0;
  registro[MAX]=0;
  tamano=0;
}
Mejores::~Mejores(void)
{
}
int Mejores::Get_tamano()
{
	return tamano;
}
void Mejores::Set_tamano(int tam)
{
	tamano=tam;
}
int Mejores::Get_vector(int posicion)
{
	return nota[posicion];
}
void Mejores::Set_vector(int posicion, int elem)
{
	nota[posicion]=elem;
}
int Mejores::Get_Registro(int posicion)
{
	return registro[posicion];
}
void Mejores::Set_Registro(int posicion, int elem)
{
	registro[posicion]=elem;
}
void Mejores::Incrementar()
{
	tamano++;
}
bool Mejores::Lleno_vector()
{if(Get_tamano()==MAX-1)
	{
      return true;
	}
	else
	{
		return false;
	}
}
bool Mejores::Insertar(int elem, int posicion)
{if((posicion<0)&&(posicion>Get_tamano()))
	{return false;
	}
	else
	{if(Lleno_vector()==true)
	 {return false;
	 }
	 else
	 {int i=Get_tamano();
		 while(i>posicion)
		 {
			 nota[i]=nota[i-1]; //mover el vector un elemento hacia abajo
			 i--;

		 }
		 nota[posicion]=elem;
				//Incrementar();
				return true;
	 } 
	}
}
bool Mejores::InsertarReg(int elem, int posicion)
{if((posicion<0)&&(posicion>Get_tamano()))
	{return false;
	}
	else
	{if(Lleno_vector()==true)
	 {return false;
	 }
	 else
	 {int i=Get_tamano();
		 while(i>posicion)
		 {
			 registro[i]=registro[i-1]; //mover el vector un elemento hacia abajo
			 i--;

		 }
		 registro[posicion]=elem;
				//Incrementar();
				return true;
	 } 
	}
}
void Mejores::ordenar ()
{int aux,auxr;
	for(int i=0; i<(Get_tamano()-1); i++){
		for(int j=i; j<Get_tamano(); j++){
			if(nota[i] < nota[j]){
				aux = nota[i];
				nota[i] = nota[j];
				nota[j] = aux;
				auxr = registro[i];
				registro[i] = registro[j];
				registro[j] = auxr;
			}
		}
	}
}