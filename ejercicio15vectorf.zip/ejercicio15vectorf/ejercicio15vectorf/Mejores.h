#pragma once
#include <string>
#define MAX 100

class Mejores
{private:
 double nota[MAX];
 int registro[MAX];
 int tamano;
public:
	Mejores(void);
	~Mejores(void);
	int Get_tamano();
	void Set_tamano(int tam);
	int Get_vector(int posicion);
	void Set_vector(int posicion, int elem);
	int Get_Registro(int posicion);
	void Set_Registro(int posicion, int elem);
	void Incrementar();
	bool Lleno_vector();
	bool Insertar(int elem, int posicion);
	bool InsertarReg(int elem, int posicion);
	void ordenar ();
};

