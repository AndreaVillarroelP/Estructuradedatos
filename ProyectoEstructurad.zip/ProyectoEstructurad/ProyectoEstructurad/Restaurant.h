#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;
using namespace msclr::interop;


 class Restaurant
{string nombre;
 int nit;
public:
	Restaurant(void);
	string Get_nombre();
	int Get_nit();
	void Set_nombre(string nom);
	void Set_nit(int num);


};

