#pragma once
#include <iostream>
#include <string>
#include "OPERACIONES.h"
#include <msclr\marshal_cppstd.h>

namespace ProyectoEstructurad {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;
    using namespace std;
    using namespace msclr::interop;
    using namespace std;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	OPERACIONES op_colita;
	int evento=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grillaNombre;
	protected: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Label^  lblNit;
	private: System::Windows::Forms::Label^  lblRestaurante;
	private: System::Windows::Forms::TextBox^  txtNit;
	private: System::Windows::Forms::TextBox^  txtRestaurante;
	private: System::Windows::Forms::Button^  btnMostrar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grillaNombre = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->lblNit = (gcnew System::Windows::Forms::Label());
			this->lblRestaurante = (gcnew System::Windows::Forms::Label());
			this->txtNit = (gcnew System::Windows::Forms::TextBox());
			this->txtRestaurante = (gcnew System::Windows::Forms::TextBox());
			this->btnMostrar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaNombre))->BeginInit();
			this->SuspendLayout();
			// 
			// grillaNombre
			// 
			this->grillaNombre->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaNombre->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, 
				this->Column2});
			this->grillaNombre->Location = System::Drawing::Point(25, 272);
			this->grillaNombre->Name = L"grillaNombre";
			this->grillaNombre->RowTemplate->Height = 28;
			this->grillaNombre->Size = System::Drawing::Size(717, 290);
			this->grillaNombre->TabIndex = 0;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"NIT";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Restaurante";
			this->Column2->Name = L"Column2";
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(250, 73);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(180, 41);
			this->btnIngresar->TabIndex = 1;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// lblNit
			// 
			this->lblNit->AutoSize = true;
			this->lblNit->Location = System::Drawing::Point(44, 22);
			this->lblNit->Name = L"lblNit";
			this->lblNit->Size = System::Drawing::Size(28, 20);
			this->lblNit->TabIndex = 2;
			this->lblNit->Text = L"Nit";
			// 
			// lblRestaurante
			// 
			this->lblRestaurante->AutoSize = true;
			this->lblRestaurante->Location = System::Drawing::Point(373, 22);
			this->lblRestaurante->Name = L"lblRestaurante";
			this->lblRestaurante->Size = System::Drawing::Size(98, 20);
			this->lblRestaurante->TabIndex = 3;
			this->lblRestaurante->Text = L"Restaurante";
			// 
			// txtNit
			// 
			this->txtNit->Location = System::Drawing::Point(101, 16);
			this->txtNit->Name = L"txtNit";
			this->txtNit->Size = System::Drawing::Size(207, 26);
			this->txtNit->TabIndex = 4;
			// 
			// txtRestaurante
			// 
			this->txtRestaurante->Location = System::Drawing::Point(477, 16);
			this->txtRestaurante->Name = L"txtRestaurante";
			this->txtRestaurante->Size = System::Drawing::Size(181, 26);
			this->txtRestaurante->TabIndex = 5;
			// 
			// btnMostrar
			// 
			this->btnMostrar->Location = System::Drawing::Point(255, 131);
			this->btnMostrar->Name = L"btnMostrar";
			this->btnMostrar->Size = System::Drawing::Size(175, 39);
			this->btnMostrar->TabIndex = 6;
			this->btnMostrar->Text = L"Mostrar";
			this->btnMostrar->UseVisualStyleBackColor = true;
			this->btnMostrar->Click += gcnew System::EventHandler(this, &Form1::btnMostrar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(760, 590);
			this->Controls->Add(this->btnMostrar);
			this->Controls->Add(this->txtRestaurante);
			this->Controls->Add(this->txtNit);
			this->Controls->Add(this->lblRestaurante);
			this->Controls->Add(this->lblNit);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->grillaNombre);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaNombre))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
		     Restaurant informacion;
			 informacion.Set_nit(System::Convert::ToInt32(txtNit->Text));
			 informacion.Set_nombre(marshal_as<std::string>(System::Convert::ToString(txtRestaurante->Text)));
			 op_colita.Insertar(informacion);
			 }
private: System::Void btnMostrar_Click(System::Object^  sender, System::EventArgs^  e) {
			    if(evento>=1)
		 {
		     op_colita.Guardar_cola_grilla(grillaNombre);

		 }
		 evento=1;
		 }
};
}

