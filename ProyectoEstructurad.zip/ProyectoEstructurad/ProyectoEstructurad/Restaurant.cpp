#include "StdAfx.h"
#include "Restaurant.h"


Restaurant::Restaurant(void)
{nombre="";
 nit=0;
}
string Restaurant::Get_nombre()
{
	return nombre;
}
int Restaurant::Get_nit()
{
	return nit;
}
void Restaurant::Set_nombre(string nom)
{
	nombre=nom;
}
void Restaurant::Set_nit(int num)
{
	nit=num;
}
