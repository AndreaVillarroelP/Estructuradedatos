#include "StdAfx.h"
#include "OPERACIONES.h"


OPERACIONES::OPERACIONES(void)
{
	Cola();
}
void OPERACIONES::Guardar_cola_grilla(DataGridView^  grilla_cola)
{
	int i;
	Restaurant nodito;
	i=0;
	Cola aux;
	aux=This_cola();
	grilla_cola->ColumnCount=2;
	grilla_cola->RowCount=Longitud_cola();
	while(aux.Cola_vacia()==false)
	{
	
		aux.Eliminar(nodito);
		grilla_cola->Rows[i]->Cells[0]->Value=System::Convert::ToString(nodito.Get_nit());
		grilla_cola->Rows[i]->Cells[1]->Value=marshal_as<System::String^>(nodito.Get_nombre());
		
	    i++;
	}
}

int OPERACIONES::Longitud_cola()
{
	int t=0;
	Cola aux;
	aux=This_cola();
	Restaurant nodito;
	while(aux.Cola_vacia()==false)
	{
	
	  aux.Eliminar(nodito);
	  //aux.Insertar(nodito);
	  t++;
	}
  // This_cola(aux);
   return t;
}