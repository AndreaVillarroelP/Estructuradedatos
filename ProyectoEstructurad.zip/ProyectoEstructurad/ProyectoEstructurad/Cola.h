#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "Restaurant.h"
using namespace std;
using namespace msclr::interop;
const int NC=5;
class Cola
{Restaurant cola[NC];
 int frente;
 int final;
public:
	Cola(void);
	bool Cola_vacia();
	bool Cola_llena();
	bool Insertar(Restaurant);
	bool Eliminar(Restaurant &);
	int  Get_frente();
	Cola This_cola();
	void This_cola(Cola);
};

