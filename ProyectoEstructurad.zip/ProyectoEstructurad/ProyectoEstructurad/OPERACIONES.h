#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "Cola.h"
using namespace System::Windows::Forms;
using namespace std;
using namespace msclr::interop;
using namespace std;
class OPERACIONES: public Cola
{
public:
	OPERACIONES(void);
	void Guardar_cola_grilla(DataGridView^  grilla_cola);
	int Longitud_cola();

};

