#include "StdAfx.h"
#include "Cola.h"


Cola::Cola(void)
{
	frente=-1;
	final=-1;
}
bool Cola::Cola_vacia()
{
	if(frente==final) { return true;}
	else { return false;}

}
bool Cola::Cola_llena()
	{
		if(final==NC-1){ return true;}
		else {return false;}
	
	}
bool Cola::Insertar(Restaurant nodito)
	{
		if(Cola_llena()==true) { return false;}
		else { final++;
		cola[final]=nodito;
		return true;
		}
	}
bool Cola::Eliminar(Restaurant &nodito)
	{
	    if(Cola_vacia()==true) { return false;}
		else { frente++;
		nodito=cola[frente];
		return true;
		}
	
	}
int  Cola::Get_frente()
	{
	   return frente+1;
	
	}

Cola Cola::This_cola()
	{
	   return *this;
	}

void Cola::This_cola(Cola x)
{
	*this=x;

}