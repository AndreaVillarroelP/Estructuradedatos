#pragma once
#include <iostream>
#include "StdAfx.h"
#include "Promedio.h"
#include "msclr\marshal_cppstd.h"
#define MAX 100
namespace Ejercicio3vectoresf {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	Promedio Vector1;
	int pos=0; //Variable universal
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grillaNota;
	protected: 

	protected: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Label^  lbltam;
	private: System::Windows::Forms::Label^  lblNota;
	private: System::Windows::Forms::TextBox^  txtTam;
	private: System::Windows::Forms::TextBox^  txtNota;




	private: System::Windows::Forms::Button^  btndefinir;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::TextBox^  txtPromedio;




	private: System::Windows::Forms::Label^  btnPromedio;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grillaNota = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->lbltam = (gcnew System::Windows::Forms::Label());
			this->lblNota = (gcnew System::Windows::Forms::Label());
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->txtNota = (gcnew System::Windows::Forms::TextBox());
			this->btndefinir = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtPromedio = (gcnew System::Windows::Forms::TextBox());
			this->btnPromedio = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaNota))->BeginInit();
			this->SuspendLayout();
			// 
			// grillaNota
			// 
			this->grillaNota->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaNota->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grillaNota->Location = System::Drawing::Point(25, 137);
			this->grillaNota->Name = L"grillaNota";
			this->grillaNota->RowTemplate->Height = 28;
			this->grillaNota->Size = System::Drawing::Size(339, 185);
			this->grillaNota->TabIndex = 0;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Nota";
			this->Column1->Name = L"Column1";
			// 
			// lbltam
			// 
			this->lbltam->AutoSize = true;
			this->lbltam->Location = System::Drawing::Point(36, 17);
			this->lbltam->Name = L"lbltam";
			this->lbltam->Size = System::Drawing::Size(67, 20);
			this->lbltam->TabIndex = 1;
			this->lbltam->Text = L"Tama�o";
			// 
			// lblNota
			// 
			this->lblNota->AutoSize = true;
			this->lblNota->Location = System::Drawing::Point(29, 66);
			this->lblNota->Name = L"lblNota";
			this->lblNota->Size = System::Drawing::Size(43, 20);
			this->lblNota->TabIndex = 2;
			this->lblNota->Text = L"Nota";
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(129, 15);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(234, 26);
			this->txtTam->TabIndex = 3;
			// 
			// txtNota
			// 
			this->txtNota->Location = System::Drawing::Point(134, 63);
			this->txtNota->Name = L"txtNota";
			this->txtNota->Size = System::Drawing::Size(228, 26);
			this->txtNota->TabIndex = 4;
			// 
			// btndefinir
			// 
			this->btndefinir->Location = System::Drawing::Point(414, 10);
			this->btndefinir->Name = L"btndefinir";
			this->btndefinir->Size = System::Drawing::Size(151, 31);
			this->btndefinir->TabIndex = 5;
			this->btndefinir->Text = L"Definir";
			this->btndefinir->UseVisualStyleBackColor = true;
			this->btndefinir->Click += gcnew System::EventHandler(this, &Form1::btndefinir_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(414, 63);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(153, 32);
			this->btnIngresar->TabIndex = 6;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(430, 208);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(198, 38);
			this->btnCalcular->TabIndex = 7;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// txtPromedio
			// 
			this->txtPromedio->Location = System::Drawing::Point(430, 160);
			this->txtPromedio->Name = L"txtPromedio";
			this->txtPromedio->Size = System::Drawing::Size(188, 26);
			this->txtPromedio->TabIndex = 8;
			// 
			// btnPromedio
			// 
			this->btnPromedio->AutoSize = true;
			this->btnPromedio->Location = System::Drawing::Point(426, 137);
			this->btnPromedio->Name = L"btnPromedio";
			this->btnPromedio->Size = System::Drawing::Size(76, 20);
			this->btnPromedio->TabIndex = 9;
			this->btnPromedio->Text = L"Promedio";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(669, 334);
			this->Controls->Add(this->btnPromedio);
			this->Controls->Add(this->txtPromedio);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btndefinir);
			this->Controls->Add(this->txtNota);
			this->Controls->Add(this->txtTam);
			this->Controls->Add(this->lblNota);
			this->Controls->Add(this->lbltam);
			this->Controls->Add(this->grillaNota);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaNota))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void btndefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=System::Convert::ToInt32(txtTam->Text);
			 Vector1.Set_tamano(tam);
			 grillaNota->RowCount=Vector1.Get_tamano();
			 pos=0;
		 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 double nota;
			 double elem;
			 elem=System::Convert::ToInt32(txtNota->Text);
			 if(Vector1.Insertar(elem,pos))
			 {pos++;
			 grillaNota->ColumnCount=1;
			 grillaNota->RowCount=Vector1.Get_tamano();
			 for(int i=0;i<Vector1.Get_tamano();i++)
			 {nota=Vector1.Get_vector(i);
			  grillaNota->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(nota);
			  

			 }
			 }

		 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 txtPromedio->Text=System::Convert::ToString(Vector1.Calcular());
		 }
};
}

