#pragma once
#define MAX 10
class Promedio
{private:
  double vec[MAX];
  int tamano;
public:
	Promedio(void);
	~Promedio(void);
	int Get_tamano();
	void Set_tamano(int tam);
	int Get_vector(int posicion);
	void Set_vector(int posicion, int elem);
	void Incrementar();
	double Calcular ();
	bool Lleno_vector();
	bool Insertar(int elem, int posicion);
	bool Vacio_vector();
};

