#include "StdAfx.h"
#include "Promedio.h"
#define MAX 100

Promedio::Promedio(void)
{ vec[MAX]=0;
  tamano=0;
}
Promedio::~Promedio(void)
{
}
int Promedio::Get_tamano()
{
	return tamano;
}
void Promedio::Set_tamano(int tam)
{
	tamano=tam;
}
int Promedio::Get_vector(int posicion)
{
	return vec[posicion];
}
void Promedio::Set_vector(int posicion, int elem)
{
	vec[posicion]=elem;
}
void Promedio::Incrementar()
{
	tamano++;
}
double Promedio::Calcular ()
{double suma=0;
  for(int i=0;i<Get_tamano();i++)
  {suma=suma+Get_vector(i);
  }
  return suma/Get_tamano() ;
}
bool Promedio::Lleno_vector()
{if(Get_tamano()==MAX-1)
	{
      return true;
	}
	else
	{
		return false;
	}
}
bool Promedio::Insertar(int elem, int posicion)
{
	if((posicion<0)&&(posicion>tamano))
	{return false;
	}
	else
	{if(Lleno_vector()==true)
	 {return false;
	 }
	 else
	 {int i=Get_tamano();
		 while(i>posicion)
		 {
			 vec[i]=vec[i-1]; //mover el vector un elemento hacia abajo
			 i--;

		 }
		 vec[posicion]=elem;
				//Incrementar();
				return true;
	 } 
	}
}
bool Promedio::Vacio_vector()
{if (tamano==0) 
		{return true;}
	else 
	{return false;}	
}