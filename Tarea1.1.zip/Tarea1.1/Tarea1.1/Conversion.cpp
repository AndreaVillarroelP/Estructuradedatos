#include "StdAfx.h"
#include "Conversion.h"


Conversion::Conversion(void)
{
}
float Conversion::Get_Celsius()
	{
		return celsius;
	}
float Conversion::Get_Kelvin()
	{
		return kelvin;
	}
void Conversion::Set_Celsius(float c)
	{
		celsius=c;
	}
void Conversion::Set_Kelvin(float k)
	{
		kelvin=k;
	}
float Conversion::Calcular()
	{
		kelvin= celsius + 273.15;
		return kelvin;
	}
