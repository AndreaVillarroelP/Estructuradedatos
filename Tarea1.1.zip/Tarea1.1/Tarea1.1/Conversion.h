#pragma once
class Conversion
{	
private:
	float celsius,kelvin;
public:
	Conversion(void);
	float Get_Celsius();
	float Get_Kelvin();
	
	
	void Set_Celsius(float c);
	void Set_Kelvin(float k);
	
	float Calcular();
};

