#pragma once
#include "Conversion.h"
#include "iostream" 
#include "msclr\marshal_cppstd.h" 

namespace Tarea11 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblCelsius;
	protected: 
	private: System::Windows::Forms::Label^  lblKelvin;
	private: System::Windows::Forms::TextBox^  txtCelsius;
	private: System::Windows::Forms::TextBox^  txtKelvin;
	private: System::Windows::Forms::Button^  btnCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblCelsius = (gcnew System::Windows::Forms::Label());
			this->lblKelvin = (gcnew System::Windows::Forms::Label());
			this->txtCelsius = (gcnew System::Windows::Forms::TextBox());
			this->txtKelvin = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblCelsius
			// 
			this->lblCelsius->AutoSize = true;
			this->lblCelsius->ForeColor = System::Drawing::SystemColors::ControlText;
			this->lblCelsius->Location = System::Drawing::Point(25, 32);
			this->lblCelsius->Name = L"lblCelsius";
			this->lblCelsius->Size = System::Drawing::Size(60, 20);
			this->lblCelsius->TabIndex = 0;
			this->lblCelsius->Text = L"Celsius";
			// 
			// lblKelvin
			// 
			this->lblKelvin->AutoSize = true;
			this->lblKelvin->Location = System::Drawing::Point(27, 98);
			this->lblKelvin->Name = L"lblKelvin";
			this->lblKelvin->Size = System::Drawing::Size(50, 20);
			this->lblKelvin->TabIndex = 1;
			this->lblKelvin->Text = L"Kelvin";
			// 
			// txtCelsius
			// 
			this->txtCelsius->Location = System::Drawing::Point(148, 32);
			this->txtCelsius->Name = L"txtCelsius";
			this->txtCelsius->Size = System::Drawing::Size(112, 26);
			this->txtCelsius->TabIndex = 2;
			// 
			// txtKelvin
			// 
			this->txtKelvin->Location = System::Drawing::Point(148, 99);
			this->txtKelvin->Name = L"txtKelvin";
			this->txtKelvin->Size = System::Drawing::Size(112, 26);
			this->txtKelvin->TabIndex = 3;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(87, 168);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(121, 42);
			this->btnCalcular->TabIndex = 4;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(278, 244);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtKelvin);
			this->Controls->Add(this->txtCelsius);
			this->Controls->Add(this->lblKelvin);
			this->Controls->Add(this->lblCelsius);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
		 Conversion grado; //Creando el objeto cuadradito
		 grado.Set_Celsius(System::Convert::ToInt32(txtCelsius->Text));
		 float gradofin;
		 gradofin=grado.Calcular();
		 txtKelvin->Text=System::Convert::ToString(gradofin);
			 }
};
}

