#pragma once
#include "Cuenta.h"
#include <iostream>
#include <string>
#include "msclr\marshal_cppstd.h" //Manejar texto

namespace EjemploBancoForm {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btSaldo;
	protected: 

	protected: 

	protected: 

	private: System::Windows::Forms::Label^  lblNombre;
	private: System::Windows::Forms::Label^  lblCuenta;
	private: System::Windows::Forms::Label^  lblIngreso;


	private: System::Windows::Forms::Label^  lblSaldo;
	private: System::Windows::Forms::TextBox^  txtNombre;
	private: System::Windows::Forms::TextBox^  txtCuenta;
	private: System::Windows::Forms::TextBox^  txtIngreso;
	private: System::Windows::Forms::TextBox^  txtSaldo;
	private: System::Windows::Forms::Button^  btEgreso;
	private: System::Windows::Forms::Button^  btConsulta;


	protected: 









	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btSaldo = (gcnew System::Windows::Forms::Button());
			this->lblNombre = (gcnew System::Windows::Forms::Label());
			this->lblCuenta = (gcnew System::Windows::Forms::Label());
			this->lblIngreso = (gcnew System::Windows::Forms::Label());
			this->lblSaldo = (gcnew System::Windows::Forms::Label());
			this->txtNombre = (gcnew System::Windows::Forms::TextBox());
			this->txtCuenta = (gcnew System::Windows::Forms::TextBox());
			this->txtIngreso = (gcnew System::Windows::Forms::TextBox());
			this->txtSaldo = (gcnew System::Windows::Forms::TextBox());
			this->btEgreso = (gcnew System::Windows::Forms::Button());
			this->btConsulta = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// btSaldo
			// 
			this->btSaldo->Location = System::Drawing::Point(2, 190);
			this->btSaldo->Name = L"btSaldo";
			this->btSaldo->Size = System::Drawing::Size(133, 42);
			this->btSaldo->TabIndex = 0;
			this->btSaldo->Text = L"Ingreso";
			this->btSaldo->UseVisualStyleBackColor = true;
			this->btSaldo->Click += gcnew System::EventHandler(this, &Form1::btSaldo_Click);
			// 
			// lblNombre
			// 
			this->lblNombre->AutoSize = true;
			this->lblNombre->Location = System::Drawing::Point(19, 18);
			this->lblNombre->Name = L"lblNombre";
			this->lblNombre->Size = System::Drawing::Size(65, 20);
			this->lblNombre->TabIndex = 1;
			this->lblNombre->Text = L"Nombre";
			// 
			// lblCuenta
			// 
			this->lblCuenta->AutoSize = true;
			this->lblCuenta->Location = System::Drawing::Point(19, 54);
			this->lblCuenta->Name = L"lblCuenta";
			this->lblCuenta->Size = System::Drawing::Size(61, 20);
			this->lblCuenta->TabIndex = 2;
			this->lblCuenta->Text = L"Cuenta";
			// 
			// lblIngreso
			// 
			this->lblIngreso->AutoSize = true;
			this->lblIngreso->Location = System::Drawing::Point(19, 93);
			this->lblIngreso->Name = L"lblIngreso";
			this->lblIngreso->Size = System::Drawing::Size(63, 20);
			this->lblIngreso->TabIndex = 3;
			this->lblIngreso->Text = L"Ingreso";
			// 
			// lblSaldo
			// 
			this->lblSaldo->AutoSize = true;
			this->lblSaldo->Location = System::Drawing::Point(19, 129);
			this->lblSaldo->Name = L"lblSaldo";
			this->lblSaldo->Size = System::Drawing::Size(50, 20);
			this->lblSaldo->TabIndex = 4;
			this->lblSaldo->Text = L"Saldo";
			// 
			// txtNombre
			// 
			this->txtNombre->Location = System::Drawing::Point(159, 12);
			this->txtNombre->Name = L"txtNombre";
			this->txtNombre->Size = System::Drawing::Size(95, 26);
			this->txtNombre->TabIndex = 5;
			// 
			// txtCuenta
			// 
			this->txtCuenta->Location = System::Drawing::Point(159, 48);
			this->txtCuenta->Name = L"txtCuenta";
			this->txtCuenta->Size = System::Drawing::Size(95, 26);
			this->txtCuenta->TabIndex = 6;
			// 
			// txtIngreso
			// 
			this->txtIngreso->Location = System::Drawing::Point(159, 87);
			this->txtIngreso->Name = L"txtIngreso";
			this->txtIngreso->Size = System::Drawing::Size(95, 26);
			this->txtIngreso->TabIndex = 7;
			// 
			// txtSaldo
			// 
			this->txtSaldo->Location = System::Drawing::Point(159, 129);
			this->txtSaldo->Name = L"txtSaldo";
			this->txtSaldo->Size = System::Drawing::Size(95, 26);
			this->txtSaldo->TabIndex = 8;
			// 
			// btEgreso
			// 
			this->btEgreso->Location = System::Drawing::Point(141, 190);
			this->btEgreso->Name = L"btEgreso";
			this->btEgreso->Size = System::Drawing::Size(152, 42);
			this->btEgreso->TabIndex = 9;
			this->btEgreso->Text = L"Egreso";
			this->btEgreso->UseVisualStyleBackColor = true;
			this->btEgreso->Click += gcnew System::EventHandler(this, &Form1::btEgreso_Click);
			// 
			// btConsulta
			// 
			this->btConsulta->Location = System::Drawing::Point(302, 192);
			this->btConsulta->Name = L"btConsulta";
			this->btConsulta->Size = System::Drawing::Size(125, 39);
			this->btConsulta->TabIndex = 10;
			this->btConsulta->Text = L"Consulta";
			this->btConsulta->UseVisualStyleBackColor = true;
			this->btConsulta->Click += gcnew System::EventHandler(this, &Form1::btConsulta_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(437, 242);
			this->Controls->Add(this->btConsulta);
			this->Controls->Add(this->btEgreso);
			this->Controls->Add(this->txtSaldo);
			this->Controls->Add(this->txtIngreso);
			this->Controls->Add(this->txtCuenta);
			this->Controls->Add(this->txtNombre);
			this->Controls->Add(this->lblSaldo);
			this->Controls->Add(this->lblIngreso);
			this->Controls->Add(this->lblCuenta);
			this->Controls->Add(this->lblNombre);
			this->Controls->Add(this->btSaldo);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
   private: System::Void btSaldo_Click(System::Object^  sender, System::EventArgs^  e) {
			 Cuenta cuenta1;
			 //damos valor a los atributos de la clase
			 cuenta1.set_Nombre(marshal_as<std::string>(System::Convert::ToString(txtNombre->Text)));
             cuenta1.set_Cuenta	(marshal_as<std::string>(System::Convert::ToString(txtCuenta->Text)));	
			 cuenta1.ingreso(System::Convert::ToDouble(txtIngreso->Text));
			 //mostrar un valor de los atributos de la clase
			 txtSaldo->Text=System::Convert::ToString(cuenta1.get_Saldo());
			}
private: System::Void btEgreso_Click(System::Object^  sender, System::EventArgs^  e) {
			 Cuenta cuenta2("","",3000, 0.0);
			 cuenta2.set_Nombre(marshal_as<std::string>(System::Convert::ToString(txtNombre->Text)));
             cuenta2.set_Cuenta	(marshal_as<std::string>(System::Convert::ToString(txtCuenta->Text)));	
			 cuenta2.reintegro(System::Convert::ToDouble(txtIngreso->Text));
			 txtSaldo->Text=System::Convert::ToString(cuenta2.get_Saldo());
		 }
private: System::Void btConsulta_Click(System::Object^  sender, System::EventArgs^  e) {
			 Cuenta cuenta3("","",3000, 0.0);
			 cuenta3.set_Nombre(marshal_as<std::string>(System::Convert::ToString(txtNombre->Text)));
             cuenta3.set_Cuenta	(marshal_as<std::string>(System::Convert::ToString(txtCuenta->Text)));	
			 txtSaldo->Text=System::Convert::ToString(cuenta3.estado());
		 }
};
}

