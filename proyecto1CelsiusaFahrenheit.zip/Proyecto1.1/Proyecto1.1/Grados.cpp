#include "StdAfx.h"
#include "Grados.h"


Grados::Grados(void)
{
}
//para accesar o revisar el contenido de los atributos
float Grados::Get_celsius()
	{
		return celsius;
	}
float Grados::Get_fahrenheit()
	{
		return fahrenheit;
	}
//para darle valor a los atributos
void Grados::set_celsius(float c)
	{
		celsius=c;
	}
void Grados::set_fahrenheit(float f)
	{
		fahrenheit=f;
	}
//operaciones especificas
float Grados::Calcular()
	{
		fahrenheit= ((9*celsius)/5) +32;
		return fahrenheit;
	}

