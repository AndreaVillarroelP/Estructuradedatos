#pragma once
 class Grados
{
private://atributos
	float celsius,fahrenheit;
public://metodos
	Grados(void);//constructor
	//para accesar o revisar el contenido de los atributos
	float Get_celsius();
	float Get_fahrenheit();
	
	//para darle valor a los atributos
	void set_celsius(float c);
	void set_fahrenheit(float f);
	//operaciones especificas
	float Calcular();

};

