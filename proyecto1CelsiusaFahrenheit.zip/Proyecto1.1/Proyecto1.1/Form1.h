#pragma once
#include "Grados.h"
#include <iostream> //Manejo de interaccion
#include "msclr\marshal_cppstd.h" //Manejar texto
namespace Proyecto11 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblCelsius;
	protected: 
	private: System::Windows::Forms::Label^  lblFahrenheit;
	private: System::Windows::Forms::TextBox^  txtCelsius;
	private: System::Windows::Forms::TextBox^  txtFahrenheit;
	private: System::Windows::Forms::Button^  btCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblCelsius = (gcnew System::Windows::Forms::Label());
			this->lblFahrenheit = (gcnew System::Windows::Forms::Label());
			this->txtCelsius = (gcnew System::Windows::Forms::TextBox());
			this->txtFahrenheit = (gcnew System::Windows::Forms::TextBox());
			this->btCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblCelsius
			// 
			this->lblCelsius->AutoSize = true;
			this->lblCelsius->Location = System::Drawing::Point(22, 32);
			this->lblCelsius->Name = L"lblCelsius";
			this->lblCelsius->Size = System::Drawing::Size(60, 20);
			this->lblCelsius->TabIndex = 0;
			this->lblCelsius->Text = L"Celsius";
			// 
			// lblFahrenheit
			// 
			this->lblFahrenheit->AutoSize = true;
			this->lblFahrenheit->Location = System::Drawing::Point(22, 92);
			this->lblFahrenheit->Name = L"lblFahrenheit";
			this->lblFahrenheit->Size = System::Drawing::Size(86, 20);
			this->lblFahrenheit->TabIndex = 1;
			this->lblFahrenheit->Text = L"Fahrenheit";
			// 
			// txtCelsius
			// 
			this->txtCelsius->Location = System::Drawing::Point(140, 26);
			this->txtCelsius->Name = L"txtCelsius";
			this->txtCelsius->Size = System::Drawing::Size(118, 26);
			this->txtCelsius->TabIndex = 2;
			// 
			// txtFahrenheit
			// 
			this->txtFahrenheit->Location = System::Drawing::Point(140, 86);
			this->txtFahrenheit->Name = L"txtFahrenheit";
			this->txtFahrenheit->Size = System::Drawing::Size(114, 26);
			this->txtFahrenheit->TabIndex = 3;
			// 
			// btCalcular
			// 
			this->btCalcular->Location = System::Drawing::Point(69, 161);
			this->btCalcular->Name = L"btCalcular";
			this->btCalcular->Size = System::Drawing::Size(130, 37);
			this->btCalcular->TabIndex = 4;
			this->btCalcular->Text = L"Calcular";
			this->btCalcular->UseVisualStyleBackColor = true;
			this->btCalcular->Click += gcnew System::EventHandler(this, &Form1::btCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(278, 244);
			this->Controls->Add(this->btCalcular);
			this->Controls->Add(this->txtFahrenheit);
			this->Controls->Add(this->txtCelsius);
			this->Controls->Add(this->lblFahrenheit);
			this->Controls->Add(this->lblCelsius);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
		 Grados gradito; //Creando el objeto cuadradito
		 gradito.set_celsius(System::Convert::ToInt32(txtCelsius->Text));
		 float gradosfin;
		 gradosfin=gradito.Calcular();
		 txtFahrenheit->Text=System::Convert::ToString(gradosfin);
			 }
};
}

