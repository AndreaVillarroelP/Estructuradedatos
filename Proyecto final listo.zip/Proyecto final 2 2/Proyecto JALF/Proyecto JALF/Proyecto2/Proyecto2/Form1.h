#pragma once
#include <iostream>
#include <string>
#include "Operaciones.h"
#include <msclr\marshal_cppstd.h>
#include <Windows.h>
#include "Usuario.h"
#define USUARITO "ArchivosUsuario.dat"
namespace Proyecto2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
		    using namespace msclr::interop;
    using namespace std;
	Operaciones colita;
	Restaurant infor;
	Usuario regis;
	int evento=0;
	int opc=0;
	int codigo=1;
	int codi=1;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblJalf;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::DataGridView^  grillaRestaurant;
	private: System::Windows::Forms::Button^  btnMostrar;
	private: System::Windows::Forms::Button^  btnOpcion;
	private: System::Windows::Forms::TextBox^  txtOpcion;
	private: System::Windows::Forms::Label^  lblOpcion;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::Button^  btnAtras;
	private: System::Windows::Forms::Label^  lblRes1;
	private: System::Windows::Forms::Label^  lblDir1;
	private: System::Windows::Forms::PictureBox^  pic1;
	private: System::Windows::Forms::Label^  lblmen;

	private: System::Windows::Forms::Label^  lblpeque;
	private: System::Windows::Forms::ListBox^  list1;
	private: System::Windows::Forms::Label^  lblmesas;
	private: System::Windows::Forms::TextBox^  txtmesas;
	private: System::Windows::Forms::Label^  lblpregunta;
	private: System::Windows::Forms::TextBox^  txtCantidad;
	private: System::Windows::Forms::Button^  btnReservar;
	private: System::Windows::Forms::Label^  lblRes2;
	private: System::Windows::Forms::Label^  lblDir2;
	private: System::Windows::Forms::PictureBox^  pic2;
	private: System::Windows::Forms::ListBox^  list2;
	private: System::Windows::Forms::Label^  lblRes3;
	private: System::Windows::Forms::Label^  lblDir3;
	private: System::Windows::Forms::PictureBox^  pic3;
	private: System::Windows::Forms::ListBox^  list3;
	private: System::Windows::Forms::Label^  lblRes4;
	private: System::Windows::Forms::Label^  lblDir4;
	private: System::Windows::Forms::PictureBox^  pic4;
	private: System::Windows::Forms::ListBox^  list4;
	private: System::Windows::Forms::Label^  lblRes5;
	private: System::Windows::Forms::Label^  lblDir5;
	private: System::Windows::Forms::PictureBox^  pic5;
	private: System::Windows::Forms::ListBox^  list5;
	private: System::Windows::Forms::Label^  lblUsuario;
	private: System::Windows::Forms::Label^  lblContra;
	private: System::Windows::Forms::Button^  btnRegistrar;
	private: System::Windows::Forms::TextBox^  txtUsuario;
	private: System::Windows::Forms::TextBox^  txtContra;
	private: System::Windows::Forms::TextBox^  txtRegis;
	private: System::Windows::Forms::TextBox^  txtRegiscont;

	private: System::Windows::Forms::Label^  lblTelefono;
	private: System::Windows::Forms::TextBox^  txtTelefono;
	private: System::Windows::Forms::Button^  btnRegis;
	private: System::Windows::Forms::ComboBox^  cmbHora;
	private: System::Windows::Forms::Label^  lblHora;
	private: System::Windows::Forms::ComboBox^  cmbDia;
	private: System::Windows::Forms::Label^  lblDia;
	private: System::Windows::Forms::Button^  btnCompletar;







	protected: 


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->lblJalf = (gcnew System::Windows::Forms::Label());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->grillaRestaurant = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnMostrar = (gcnew System::Windows::Forms::Button());
			this->btnOpcion = (gcnew System::Windows::Forms::Button());
			this->txtOpcion = (gcnew System::Windows::Forms::TextBox());
			this->lblOpcion = (gcnew System::Windows::Forms::Label());
			this->btnAtras = (gcnew System::Windows::Forms::Button());
			this->lblRes1 = (gcnew System::Windows::Forms::Label());
			this->lblDir1 = (gcnew System::Windows::Forms::Label());
			this->pic1 = (gcnew System::Windows::Forms::PictureBox());
			this->lblmen = (gcnew System::Windows::Forms::Label());
			this->lblpeque = (gcnew System::Windows::Forms::Label());
			this->list1 = (gcnew System::Windows::Forms::ListBox());
			this->lblmesas = (gcnew System::Windows::Forms::Label());
			this->txtmesas = (gcnew System::Windows::Forms::TextBox());
			this->lblpregunta = (gcnew System::Windows::Forms::Label());
			this->txtCantidad = (gcnew System::Windows::Forms::TextBox());
			this->btnReservar = (gcnew System::Windows::Forms::Button());
			this->lblRes2 = (gcnew System::Windows::Forms::Label());
			this->lblDir2 = (gcnew System::Windows::Forms::Label());
			this->pic2 = (gcnew System::Windows::Forms::PictureBox());
			this->list2 = (gcnew System::Windows::Forms::ListBox());
			this->lblRes3 = (gcnew System::Windows::Forms::Label());
			this->lblDir3 = (gcnew System::Windows::Forms::Label());
			this->pic3 = (gcnew System::Windows::Forms::PictureBox());
			this->list3 = (gcnew System::Windows::Forms::ListBox());
			this->lblRes4 = (gcnew System::Windows::Forms::Label());
			this->lblDir4 = (gcnew System::Windows::Forms::Label());
			this->pic4 = (gcnew System::Windows::Forms::PictureBox());
			this->list4 = (gcnew System::Windows::Forms::ListBox());
			this->lblRes5 = (gcnew System::Windows::Forms::Label());
			this->lblDir5 = (gcnew System::Windows::Forms::Label());
			this->pic5 = (gcnew System::Windows::Forms::PictureBox());
			this->list5 = (gcnew System::Windows::Forms::ListBox());
			this->lblUsuario = (gcnew System::Windows::Forms::Label());
			this->lblContra = (gcnew System::Windows::Forms::Label());
			this->btnRegistrar = (gcnew System::Windows::Forms::Button());
			this->txtUsuario = (gcnew System::Windows::Forms::TextBox());
			this->txtContra = (gcnew System::Windows::Forms::TextBox());
			this->txtRegis = (gcnew System::Windows::Forms::TextBox());
			this->txtRegiscont = (gcnew System::Windows::Forms::TextBox());
			this->lblTelefono = (gcnew System::Windows::Forms::Label());
			this->txtTelefono = (gcnew System::Windows::Forms::TextBox());
			this->btnRegis = (gcnew System::Windows::Forms::Button());
			this->cmbHora = (gcnew System::Windows::Forms::ComboBox());
			this->lblHora = (gcnew System::Windows::Forms::Label());
			this->cmbDia = (gcnew System::Windows::Forms::ComboBox());
			this->lblDia = (gcnew System::Windows::Forms::Label());
			this->btnCompletar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaRestaurant))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic5))->BeginInit();
			this->SuspendLayout();
			// 
			// lblJalf
			// 
			this->lblJalf->AutoSize = true;
			this->lblJalf->BackColor = System::Drawing::Color::Transparent;
			this->lblJalf->Font = (gcnew System::Drawing::Font(L"Onyx", 72, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblJalf->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->lblJalf->Location = System::Drawing::Point(118, 73);
			this->lblJalf->Name = L"lblJalf";
			this->lblJalf->Size = System::Drawing::Size(243, 160);
			this->lblJalf->TabIndex = 0;
			this->lblJalf->Text = L"JALF";
			// 
			// btnIngresar
			// 
			this->btnIngresar->BackColor = System::Drawing::Color::Black;
			this->btnIngresar->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->btnIngresar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnIngresar->ForeColor = System::Drawing::SystemColors::Control;
			this->btnIngresar->Location = System::Drawing::Point(70, 362);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(135, 60);
			this->btnIngresar->TabIndex = 1;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = false;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// grillaRestaurant
			// 
			this->grillaRestaurant->BackgroundColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->grillaRestaurant->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->grillaRestaurant->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaRestaurant->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {this->Column1, 
				this->Column2, this->Column3});
			this->grillaRestaurant->GridColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->grillaRestaurant->Location = System::Drawing::Point(39, 56);
			this->grillaRestaurant->Name = L"grillaRestaurant";
			this->grillaRestaurant->RowTemplate->Height = 28;
			this->grillaRestaurant->Size = System::Drawing::Size(373, 300);
			this->grillaRestaurant->TabIndex = 2;
			this->grillaRestaurant->Visible = false;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"n";
			this->Column1->Name = L"Column1";
			this->Column1->Width = 25;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Restaurante";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Direccion";
			this->Column3->Name = L"Column3";
			// 
			// btnMostrar
			// 
			this->btnMostrar->BackColor = System::Drawing::SystemColors::ControlText;
			this->btnMostrar->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnMostrar->Location = System::Drawing::Point(177, 362);
			this->btnMostrar->Name = L"btnMostrar";
			this->btnMostrar->Size = System::Drawing::Size(134, 54);
			this->btnMostrar->TabIndex = 3;
			this->btnMostrar->Text = L"Mostrar";
			this->btnMostrar->UseVisualStyleBackColor = false;
			this->btnMostrar->Visible = false;
			this->btnMostrar->Click += gcnew System::EventHandler(this, &Form1::btnMostrar_Click);
			// 
			// btnOpcion
			// 
			this->btnOpcion->BackColor = System::Drawing::SystemColors::Desktop;
			this->btnOpcion->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnOpcion->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnOpcion->Location = System::Drawing::Point(314, 446);
			this->btnOpcion->Name = L"btnOpcion";
			this->btnOpcion->Size = System::Drawing::Size(109, 41);
			this->btnOpcion->TabIndex = 4;
			this->btnOpcion->Text = L"Aceptar";
			this->btnOpcion->UseVisualStyleBackColor = false;
			this->btnOpcion->Visible = false;
			this->btnOpcion->Click += gcnew System::EventHandler(this, &Form1::btnOpcion_Click);
			// 
			// txtOpcion
			// 
			this->txtOpcion->Location = System::Drawing::Point(136, 453);
			this->txtOpcion->Name = L"txtOpcion";
			this->txtOpcion->Size = System::Drawing::Size(164, 26);
			this->txtOpcion->TabIndex = 5;
			this->txtOpcion->Visible = false;
			// 
			// lblOpcion
			// 
			this->lblOpcion->AutoSize = true;
			this->lblOpcion->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblOpcion->Location = System::Drawing::Point(95, 422);
			this->lblOpcion->Name = L"lblOpcion";
			this->lblOpcion->Size = System::Drawing::Size(280, 20);
			this->lblOpcion->TabIndex = 6;
			this->lblOpcion->Text = L"Ingresar Opcion donde desea reservar";
			this->lblOpcion->Visible = false;
			// 
			// btnAtras
			// 
			this->btnAtras->BackColor = System::Drawing::SystemColors::InfoText;
			this->btnAtras->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnAtras->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnAtras->Location = System::Drawing::Point(338, 511);
			this->btnAtras->Name = L"btnAtras";
			this->btnAtras->Size = System::Drawing::Size(97, 35);
			this->btnAtras->TabIndex = 7;
			this->btnAtras->Text = L"Atras";
			this->btnAtras->UseVisualStyleBackColor = false;
			this->btnAtras->Visible = false;
			this->btnAtras->Click += gcnew System::EventHandler(this, &Form1::btnAtras_Click);
			// 
			// lblRes1
			// 
			this->lblRes1->AutoSize = true;
			this->lblRes1->BackColor = System::Drawing::Color::Transparent;
			this->lblRes1->Font = (gcnew System::Drawing::Font(L"Onyx", 22, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblRes1->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblRes1->Location = System::Drawing::Point(110, 4);
			this->lblRes1->Name = L"lblRes1";
			this->lblRes1->Size = System::Drawing::Size(219, 49);
			this->lblRes1->TabIndex = 8;
			this->lblRes1->Text = L"021 Hall Resto Bar";
			this->lblRes1->Visible = false;
			// 
			// lblDir1
			// 
			this->lblDir1->AutoSize = true;
			this->lblDir1->BackColor = System::Drawing::Color::Transparent;
			this->lblDir1->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblDir1->Location = System::Drawing::Point(35, 53);
			this->lblDir1->Name = L"lblDir1";
			this->lblDir1->Size = System::Drawing::Size(362, 20);
			this->lblDir1->TabIndex = 9;
			this->lblDir1->Text = L"Av. Alemana 3er. Anillo externo esquina Av. Japon";
			this->lblDir1->Visible = false;
			// 
			// pic1
			// 
			this->pic1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pic1.BackgroundImage")));
			this->pic1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pic1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pic1->ErrorImage = nullptr;
			this->pic1->Location = System::Drawing::Point(134, 78);
			this->pic1->Name = L"pic1";
			this->pic1->Size = System::Drawing::Size(180, 155);
			this->pic1->TabIndex = 10;
			this->pic1->TabStop = false;
			this->pic1->Visible = false;
			// 
			// lblmen
			// 
			this->lblmen->AutoSize = true;
			this->lblmen->BackColor = System::Drawing::Color::Transparent;
			this->lblmen->Font = (gcnew System::Drawing::Font(L"Onyx", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblmen->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblmen->Location = System::Drawing::Point(12, 231);
			this->lblmen->Name = L"lblmen";
			this->lblmen->Size = System::Drawing::Size(62, 41);
			this->lblmen->TabIndex = 11;
			this->lblmen->Text = L"Menu";
			this->lblmen->Visible = false;
			// 
			// lblpeque
			// 
			this->lblpeque->AutoSize = true;
			this->lblpeque->BackColor = System::Drawing::Color::Transparent;
			this->lblpeque->Font = (gcnew System::Drawing::Font(L"Onyx", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblpeque->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblpeque->Location = System::Drawing::Point(17, 509);
			this->lblpeque->Name = L"lblpeque";
			this->lblpeque->Size = System::Drawing::Size(61, 41);
			this->lblpeque->TabIndex = 12;
			this->lblpeque->Text = L"JALF";
			this->lblpeque->Visible = false;
			// 
			// list1
			// 
			this->list1->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->list1->ForeColor = System::Drawing::SystemColors::Window;
			this->list1->FormattingEnabled = true;
			this->list1->ItemHeight = 20;
			this->list1->Items->AddRange(gcnew cli::array< System::Object^  >(6) {L"�Haburguesas", L"�Pica�a", L"�Nachos", L"�Alitas", 
				L"�Pastas", L""});
			this->list1->Location = System::Drawing::Point(14, 275);
			this->list1->Name = L"list1";
			this->list1->Size = System::Drawing::Size(236, 124);
			this->list1->TabIndex = 13;
			this->list1->Visible = false;
			// 
			// lblmesas
			// 
			this->lblmesas->AutoSize = true;
			this->lblmesas->BackColor = System::Drawing::Color::Transparent;
			this->lblmesas->Font = (gcnew System::Drawing::Font(L"Onyx", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblmesas->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblmesas->Location = System::Drawing::Point(265, 236);
			this->lblmesas->Name = L"lblmesas";
			this->lblmesas->Size = System::Drawing::Size(170, 41);
			this->lblmesas->TabIndex = 14;
			this->lblmesas->Text = L"Mesas Disponibles";
			this->lblmesas->Visible = false;
			// 
			// txtmesas
			// 
			this->txtmesas->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->txtmesas->ForeColor = System::Drawing::SystemColors::Window;
			this->txtmesas->Location = System::Drawing::Point(269, 275);
			this->txtmesas->Name = L"txtmesas";
			this->txtmesas->Size = System::Drawing::Size(166, 26);
			this->txtmesas->TabIndex = 15;
			this->txtmesas->Visible = false;
			// 
			// lblpregunta
			// 
			this->lblpregunta->AutoSize = true;
			this->lblpregunta->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblpregunta->Location = System::Drawing::Point(16, 410);
			this->lblpregunta->Name = L"lblpregunta";
			this->lblpregunta->Size = System::Drawing::Size(289, 20);
			this->lblpregunta->TabIndex = 16;
			this->lblpregunta->Text = L"Para cuantas personas desea la mesa\?";
			this->lblpregunta->Visible = false;
			// 
			// txtCantidad
			// 
			this->txtCantidad->Location = System::Drawing::Point(24, 435);
			this->txtCantidad->Name = L"txtCantidad";
			this->txtCantidad->Size = System::Drawing::Size(110, 26);
			this->txtCantidad->TabIndex = 17;
			this->txtCantidad->Visible = false;
			// 
			// btnReservar
			// 
			this->btnReservar->BackColor = System::Drawing::SystemColors::Desktop;
			this->btnReservar->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnReservar->Location = System::Drawing::Point(145, 433);
			this->btnReservar->Name = L"btnReservar";
			this->btnReservar->Size = System::Drawing::Size(102, 35);
			this->btnReservar->TabIndex = 18;
			this->btnReservar->Text = L"Reservar";
			this->btnReservar->UseVisualStyleBackColor = false;
			this->btnReservar->Visible = false;
			this->btnReservar->Click += gcnew System::EventHandler(this, &Form1::btnReservar_Click);
			// 
			// lblRes2
			// 
			this->lblRes2->AutoSize = true;
			this->lblRes2->BackColor = System::Drawing::Color::Transparent;
			this->lblRes2->Font = (gcnew System::Drawing::Font(L"Onyx", 22, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblRes2->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblRes2->Location = System::Drawing::Point(136, 4);
			this->lblRes2->Name = L"lblRes2";
			this->lblRes2->Size = System::Drawing::Size(176, 49);
			this->lblRes2->TabIndex = 19;
			this->lblRes2->Text = L"Jardin de Asia";
			this->lblRes2->Visible = false;
			// 
			// lblDir2
			// 
			this->lblDir2->AutoSize = true;
			this->lblDir2->BackColor = System::Drawing::Color::Transparent;
			this->lblDir2->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblDir2->Location = System::Drawing::Point(43, 56);
			this->lblDir2->Name = L"lblDir2";
			this->lblDir2->Size = System::Drawing::Size(380, 20);
			this->lblDir2->TabIndex = 20;
			this->lblDir2->Text = L"Av Marcelo Terceros B�nzer, Santa Cruz de la Sierra";
			this->lblDir2->Visible = false;
			// 
			// pic2
			// 
			this->pic2->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pic2.BackgroundImage")));
			this->pic2->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pic2->Location = System::Drawing::Point(130, 79);
			this->pic2->Name = L"pic2";
			this->pic2->Size = System::Drawing::Size(184, 154);
			this->pic2->TabIndex = 21;
			this->pic2->TabStop = false;
			this->pic2->Visible = false;
			// 
			// list2
			// 
			this->list2->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->list2->ForeColor = System::Drawing::SystemColors::Window;
			this->list2->FormattingEnabled = true;
			this->list2->ItemHeight = 20;
			this->list2->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"�Fusi�n Asi�tica", L"�Sushi"});
			this->list2->Location = System::Drawing::Point(13, 276);
			this->list2->Name = L"list2";
			this->list2->Size = System::Drawing::Size(236, 64);
			this->list2->TabIndex = 22;
			this->list2->Visible = false;
			// 
			// lblRes3
			// 
			this->lblRes3->AutoSize = true;
			this->lblRes3->BackColor = System::Drawing::Color::Transparent;
			this->lblRes3->Font = (gcnew System::Drawing::Font(L"Onyx", 22, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblRes3->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblRes3->Location = System::Drawing::Point(146, 4);
			this->lblRes3->Name = L"lblRes3";
			this->lblRes3->Size = System::Drawing::Size(161, 49);
			this->lblRes3->TabIndex = 23;
			this->lblRes3->Text = L"Michelangelo";
			this->lblRes3->Visible = false;
			// 
			// lblDir3
			// 
			this->lblDir3->AutoSize = true;
			this->lblDir3->BackColor = System::Drawing::Color::Transparent;
			this->lblDir3->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblDir3->Location = System::Drawing::Point(20, 56);
			this->lblDir3->Name = L"lblDir3";
			this->lblDir3->Size = System::Drawing::Size(416, 20);
			this->lblDir3->TabIndex = 24;
			this->lblDir3->Text = L"Calle Chuquisaca esq. Manuel Ignacio Salvatierra No. 502";
			this->lblDir3->Visible = false;
			// 
			// pic3
			// 
			this->pic3->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pic3.BackgroundImage")));
			this->pic3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pic3->Location = System::Drawing::Point(128, 79);
			this->pic3->Name = L"pic3";
			this->pic3->Size = System::Drawing::Size(184, 154);
			this->pic3->TabIndex = 25;
			this->pic3->TabStop = false;
			this->pic3->Visible = false;
			// 
			// list3
			// 
			this->list3->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->list3->ForeColor = System::Drawing::SystemColors::Window;
			this->list3->FormattingEnabled = true;
			this->list3->ItemHeight = 20;
			this->list3->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"�Comida Italiana"});
			this->list3->Location = System::Drawing::Point(14, 275);
			this->list3->Name = L"list3";
			this->list3->Size = System::Drawing::Size(236, 44);
			this->list3->TabIndex = 26;
			this->list3->Visible = false;
			// 
			// lblRes4
			// 
			this->lblRes4->AutoSize = true;
			this->lblRes4->BackColor = System::Drawing::Color::Transparent;
			this->lblRes4->Font = (gcnew System::Drawing::Font(L"Onyx", 22, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblRes4->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblRes4->Location = System::Drawing::Point(168, 4);
			this->lblRes4->Name = L"lblRes4";
			this->lblRes4->Size = System::Drawing::Size(112, 49);
			this->lblRes4->TabIndex = 27;
			this->lblRes4->Text = L"Angelino";
			this->lblRes4->Visible = false;
			// 
			// lblDir4
			// 
			this->lblDir4->AutoSize = true;
			this->lblDir4->BackColor = System::Drawing::Color::Transparent;
			this->lblDir4->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblDir4->Location = System::Drawing::Point(124, 56);
			this->lblDir4->Name = L"lblDir4";
			this->lblDir4->Size = System::Drawing::Size(198, 20);
			this->lblDir4->TabIndex = 28;
			this->lblDir4->Text = L"Boulevard del Ventura Mall";
			this->lblDir4->Visible = false;
			// 
			// pic4
			// 
			this->pic4->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pic4.BackgroundImage")));
			this->pic4->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pic4->Location = System::Drawing::Point(128, 78);
			this->pic4->Name = L"pic4";
			this->pic4->Size = System::Drawing::Size(184, 154);
			this->pic4->TabIndex = 29;
			this->pic4->TabStop = false;
			this->pic4->Visible = false;
			// 
			// list4
			// 
			this->list4->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->list4->ForeColor = System::Drawing::SystemColors::Window;
			this->list4->FormattingEnabled = true;
			this->list4->ItemHeight = 20;
			this->list4->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"�Comida Italiana"});
			this->list4->Location = System::Drawing::Point(12, 275);
			this->list4->Name = L"list4";
			this->list4->Size = System::Drawing::Size(236, 44);
			this->list4->TabIndex = 30;
			this->list4->Visible = false;
			// 
			// lblRes5
			// 
			this->lblRes5->AutoSize = true;
			this->lblRes5->BackColor = System::Drawing::Color::Transparent;
			this->lblRes5->Font = (gcnew System::Drawing::Font(L"Onyx", 22, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->lblRes5->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblRes5->Location = System::Drawing::Point(168, 4);
			this->lblRes5->Name = L"lblRes5";
			this->lblRes5->Size = System::Drawing::Size(108, 49);
			this->lblRes5->TabIndex = 31;
			this->lblRes5->Text = L"Factory";
			this->lblRes5->Visible = false;
			// 
			// lblDir5
			// 
			this->lblDir5->AutoSize = true;
			this->lblDir5->BackColor = System::Drawing::Color::Transparent;
			this->lblDir5->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->lblDir5->Location = System::Drawing::Point(66, 56);
			this->lblDir5->Name = L"lblDir5";
			this->lblDir5->Size = System::Drawing::Size(322, 20);
			this->lblDir5->TabIndex = 32;
			this->lblDir5->Text = L"Av. Velarde esquina Juan de Garay Nro. 300";
			this->lblDir5->Visible = false;
			// 
			// pic5
			// 
			this->pic5->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"pic5.BackgroundImage")));
			this->pic5->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->pic5->Location = System::Drawing::Point(128, 76);
			this->pic5->Name = L"pic5";
			this->pic5->Size = System::Drawing::Size(184, 154);
			this->pic5->TabIndex = 33;
			this->pic5->TabStop = false;
			this->pic5->Visible = false;
			// 
			// list5
			// 
			this->list5->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->list5->ForeColor = System::Drawing::SystemColors::Window;
			this->list5->FormattingEnabled = true;
			this->list5->ItemHeight = 20;
			this->list5->Items->AddRange(gcnew cli::array< System::Object^  >(9) {L"�Hamburguesas", L"�Costillas", L"�Carne", L"�Tacos", 
				L"�Alitas", L"�Nachos", L"�Ensaladas", L"�Sopas", L"�etc."});
			this->list5->Location = System::Drawing::Point(14, 275);
			this->list5->Name = L"list5";
			this->list5->Size = System::Drawing::Size(236, 124);
			this->list5->TabIndex = 34;
			this->list5->Visible = false;
			// 
			// lblUsuario
			// 
			this->lblUsuario->AutoSize = true;
			this->lblUsuario->BackColor = System::Drawing::Color::Transparent;
			this->lblUsuario->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->lblUsuario->Location = System::Drawing::Point(70, 282);
			this->lblUsuario->Name = L"lblUsuario";
			this->lblUsuario->Size = System::Drawing::Size(64, 20);
			this->lblUsuario->TabIndex = 35;
			this->lblUsuario->Text = L"Usuario";
			// 
			// lblContra
			// 
			this->lblContra->AutoSize = true;
			this->lblContra->BackColor = System::Drawing::Color::Transparent;
			this->lblContra->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->lblContra->Location = System::Drawing::Point(70, 320);
			this->lblContra->Name = L"lblContra";
			this->lblContra->Size = System::Drawing::Size(92, 20);
			this->lblContra->TabIndex = 36;
			this->lblContra->Text = L"Contrase�a";
			// 
			// btnRegistrar
			// 
			this->btnRegistrar->BackColor = System::Drawing::Color::Black;
			this->btnRegistrar->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->btnRegistrar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnRegistrar->ForeColor = System::Drawing::SystemColors::Control;
			this->btnRegistrar->Location = System::Drawing::Point(240, 362);
			this->btnRegistrar->Name = L"btnRegistrar";
			this->btnRegistrar->Size = System::Drawing::Size(135, 60);
			this->btnRegistrar->TabIndex = 37;
			this->btnRegistrar->Text = L"Registrar";
			this->btnRegistrar->UseVisualStyleBackColor = false;
			this->btnRegistrar->Click += gcnew System::EventHandler(this, &Form1::btnRegistrar_Click);
			// 
			// txtUsuario
			// 
			this->txtUsuario->Location = System::Drawing::Point(168, 278);
			this->txtUsuario->Name = L"txtUsuario";
			this->txtUsuario->Size = System::Drawing::Size(187, 26);
			this->txtUsuario->TabIndex = 38;
			// 
			// txtContra
			// 
			this->txtContra->Location = System::Drawing::Point(168, 317);
			this->txtContra->Name = L"txtContra";
			this->txtContra->PasswordChar = '*';
			this->txtContra->Size = System::Drawing::Size(187, 26);
			this->txtContra->TabIndex = 39;
			// 
			// txtRegis
			// 
			this->txtRegis->Location = System::Drawing::Point(168, 276);
			this->txtRegis->Name = L"txtRegis";
			this->txtRegis->Size = System::Drawing::Size(186, 26);
			this->txtRegis->TabIndex = 40;
			this->txtRegis->Visible = false;
			// 
			// txtRegiscont
			// 
			this->txtRegiscont->Location = System::Drawing::Point(168, 317);
			this->txtRegiscont->Name = L"txtRegiscont";
			this->txtRegiscont->PasswordChar = '*';
			this->txtRegiscont->Size = System::Drawing::Size(186, 26);
			this->txtRegiscont->TabIndex = 41;
			this->txtRegiscont->Visible = false;
			this->txtRegiscont->TextChanged += gcnew System::EventHandler(this, &Form1::txtRegiscont_TextChanged);
			// 
			// lblTelefono
			// 
			this->lblTelefono->AutoSize = true;
			this->lblTelefono->BackColor = System::Drawing::Color::Transparent;
			this->lblTelefono->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->lblTelefono->Location = System::Drawing::Point(70, 362);
			this->lblTelefono->Name = L"lblTelefono";
			this->lblTelefono->Size = System::Drawing::Size(71, 20);
			this->lblTelefono->TabIndex = 42;
			this->lblTelefono->Text = L"Telefono";
			this->lblTelefono->Visible = false;
			// 
			// txtTelefono
			// 
			this->txtTelefono->Location = System::Drawing::Point(174, 362);
			this->txtTelefono->Name = L"txtTelefono";
			this->txtTelefono->Size = System::Drawing::Size(186, 26);
			this->txtTelefono->TabIndex = 43;
			this->txtTelefono->Visible = false;
			// 
			// btnRegis
			// 
			this->btnRegis->BackColor = System::Drawing::SystemColors::Desktop;
			this->btnRegis->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnRegis->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnRegis->Location = System::Drawing::Point(155, 401);
			this->btnRegis->Name = L"btnRegis";
			this->btnRegis->Size = System::Drawing::Size(109, 41);
			this->btnRegis->TabIndex = 44;
			this->btnRegis->Text = L"Registrar";
			this->btnRegis->UseVisualStyleBackColor = false;
			this->btnRegis->Visible = false;
			this->btnRegis->Click += gcnew System::EventHandler(this, &Form1::btnRegis_Click);
			// 
			// cmbHora
			// 
			this->cmbHora->FormattingEnabled = true;
			this->cmbHora->Items->AddRange(gcnew cli::array< System::Object^  >(8) {L"17:00", L"17:30", L"18:00", L"18:30", L"19:00", 
				L"19:30", L"20:00", L"20:30"});
			this->cmbHora->Location = System::Drawing::Point(154, 269);
			this->cmbHora->Name = L"cmbHora";
			this->cmbHora->Size = System::Drawing::Size(206, 28);
			this->cmbHora->TabIndex = 45;
			this->cmbHora->Visible = false;
			// 
			// lblHora
			// 
			this->lblHora->AutoSize = true;
			this->lblHora->BackColor = System::Drawing::Color::Transparent;
			this->lblHora->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->lblHora->Location = System::Drawing::Point(84, 277);
			this->lblHora->Name = L"lblHora";
			this->lblHora->Size = System::Drawing::Size(44, 20);
			this->lblHora->TabIndex = 46;
			this->lblHora->Text = L"Hora";
			this->lblHora->Visible = false;
			// 
			// cmbDia
			// 
			this->cmbDia->FormattingEnabled = true;
			this->cmbDia->Items->AddRange(gcnew cli::array< System::Object^  >(7) {L"Lunes", L"Martes", L"Miercoles", L"Jueves", L"Viernes", 
				L"Sabado", L"Domingo"});
			this->cmbDia->Location = System::Drawing::Point(155, 317);
			this->cmbDia->Name = L"cmbDia";
			this->cmbDia->Size = System::Drawing::Size(206, 28);
			this->cmbDia->TabIndex = 47;
			this->cmbDia->Visible = false;
			// 
			// lblDia
			// 
			this->lblDia->AutoSize = true;
			this->lblDia->BackColor = System::Drawing::Color::Transparent;
			this->lblDia->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->lblDia->Location = System::Drawing::Point(84, 317);
			this->lblDia->Name = L"lblDia";
			this->lblDia->Size = System::Drawing::Size(33, 20);
			this->lblDia->TabIndex = 48;
			this->lblDia->Text = L"Dia";
			this->lblDia->Visible = false;
			// 
			// btnCompletar
			// 
			this->btnCompletar->BackColor = System::Drawing::SystemColors::Desktop;
			this->btnCompletar->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->btnCompletar->Location = System::Drawing::Point(108, 405);
			this->btnCompletar->Name = L"btnCompletar";
			this->btnCompletar->Size = System::Drawing::Size(214, 35);
			this->btnCompletar->TabIndex = 49;
			this->btnCompletar->Text = L"Completar Reserva";
			this->btnCompletar->UseVisualStyleBackColor = false;
			this->btnCompletar->Visible = false;
			this->btnCompletar->Click += gcnew System::EventHandler(this, &Form1::btnCompletar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(447, 558);
			this->Controls->Add(this->btnCompletar);
			this->Controls->Add(this->lblDia);
			this->Controls->Add(this->cmbDia);
			this->Controls->Add(this->lblHora);
			this->Controls->Add(this->cmbHora);
			this->Controls->Add(this->btnRegis);
			this->Controls->Add(this->txtTelefono);
			this->Controls->Add(this->lblTelefono);
			this->Controls->Add(this->txtRegiscont);
			this->Controls->Add(this->txtRegis);
			this->Controls->Add(this->txtContra);
			this->Controls->Add(this->txtUsuario);
			this->Controls->Add(this->btnRegistrar);
			this->Controls->Add(this->lblContra);
			this->Controls->Add(this->lblUsuario);
			this->Controls->Add(this->list5);
			this->Controls->Add(this->pic5);
			this->Controls->Add(this->lblDir5);
			this->Controls->Add(this->lblRes5);
			this->Controls->Add(this->list4);
			this->Controls->Add(this->pic4);
			this->Controls->Add(this->lblDir4);
			this->Controls->Add(this->lblRes4);
			this->Controls->Add(this->list3);
			this->Controls->Add(this->pic3);
			this->Controls->Add(this->lblDir3);
			this->Controls->Add(this->lblRes3);
			this->Controls->Add(this->list2);
			this->Controls->Add(this->pic2);
			this->Controls->Add(this->lblDir2);
			this->Controls->Add(this->lblRes2);
			this->Controls->Add(this->btnReservar);
			this->Controls->Add(this->txtCantidad);
			this->Controls->Add(this->lblpregunta);
			this->Controls->Add(this->txtmesas);
			this->Controls->Add(this->lblmesas);
			this->Controls->Add(this->list1);
			this->Controls->Add(this->lblpeque);
			this->Controls->Add(this->lblmen);
			this->Controls->Add(this->pic1);
			this->Controls->Add(this->lblDir1);
			this->Controls->Add(this->lblRes1);
			this->Controls->Add(this->btnAtras);
			this->Controls->Add(this->lblOpcion);
			this->Controls->Add(this->txtOpcion);
			this->Controls->Add(this->btnOpcion);
			this->Controls->Add(this->btnMostrar);
			this->Controls->Add(this->grillaRestaurant);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->lblJalf);
			this->DoubleBuffered = true;
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaRestaurant))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pic5))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
				 string nomb;
				 string contra;
				 if(txtUsuario->Text!="")
				 {nomb=marshal_as<std::string>(System::Convert::ToString(txtUsuario->Text));
				 }
				 if(txtContra->Text!="")
				 {contra=marshal_as<std::string>(System::Convert::ToString(txtContra->Text));
				 }
				 int cr = 0;
				 bool k=false;
				 Usuario *usuariotemporal;	
				 usuariotemporal= new Usuario();
	             ifstream fentrada(USUARITO, ios::in | ios::binary);
		         while (usuariotemporal->leerArchivo(fentrada) == true) 
				 {
			       
			       if (usuariotemporal->Get_estado() == 'A') 
				   {
				      if(nomb==usuariotemporal->Get_nomus() && contra==usuariotemporal->Get_contra())
					  {
					this->lblJalf->Visible=false;
					this->btnIngresar->Visible=false;
					this->grillaRestaurant->Visible=true;
					this->btnMostrar->Visible=true;
					this->lblOpcion->Visible=true;
					this->btnOpcion->Visible=true;
					this->txtOpcion->Visible=true;
					this->lblpeque->Visible=true;
					this->lblUsuario->Visible=false;
					this->lblContra->Visible=false;
					 this->txtUsuario->Visible=false;
					 this->txtContra->Visible=false;
					 this->btnRegistrar->Visible=false;
					  k=true;
					  }
			        }
		         }
		       fentrada.close();
			   if(k==false)
			   {MessageBox::Show("Usuario Inexistente o ha ingresado mal un dato");
			   }

			 }
	private: System::Void btnAtras_Click(System::Object^  sender, System::EventArgs^  e) {
				 int cant;
			 if((txtCantidad->Text)!=""){
				 cant=System::Convert::ToInt32(txtCantidad->Text);}
			 else
			 {cant=0;
			 }
			 opc=System::Convert::ToInt32(txtOpcion->Text);
				 if(evento==1)
				 {this->grillaRestaurant->Visible=true;
				  this->btnMostrar->Visible=true;
				  this->lblOpcion->Visible=true;
				  this->btnOpcion->Visible=true;
				  this->txtOpcion->Visible=true;
				  this->btnAtras->Visible=false;
			this->lblRes1->Visible=false;
			 this->lblDir1->Visible=false;
			 this->pic1->Visible=false;
			 this->list1->Visible=false;
			 	this->lblRes2->Visible=false;
			 this->lblDir2->Visible=false;
			 this->pic2->Visible=false;
			 this->list2->Visible=false;
			 	this->lblRes3->Visible=false;
			 this->lblDir3->Visible=false;
			 this->pic3->Visible=false;
			 this->list3->Visible=false;
			 this->lblRes4->Visible=false;
			 this->lblDir4->Visible=false;
			 this->pic4->Visible=false;
			 this->list4->Visible=false;
			 	this->lblRes5->Visible=false;
			 this->lblDir5->Visible=false;
			 this->pic5->Visible=false;
			 this->list5->Visible=false;
			 this->lblmen->Visible=false;
			 this->lblmesas->Visible=false;
			 this->txtmesas->Visible=false;
			 this->lblpregunta->Visible=false;
			 this->txtCantidad->Visible=false;
			 this->btnReservar->Visible=false;
				  evento--;

				 }else
				 {if(evento==2){
				  this->cmbDia->Visible=false;
			      this->cmbHora->Visible=false;
                  this->lblDia->Visible=false;
			      this->lblHora->Visible=false;
				  this->btnCompletar->Visible=false;
				  switch(opc)
			 {case 1:
			 this->lblRes1->Visible=true;
			 this->lblDir1->Visible=true;
			 this->pic1->Visible=true;
			 this->lblmen->Visible=true;
			 this->list1->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 break;
			 case 2:
			 this->lblRes2->Visible=true;
			 this->lblDir2->Visible=true;
			 this->pic2->Visible=true;
			 this->list2->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 break;
			 case 3:
			 this->lblRes3->Visible=true;
			 this->lblDir3->Visible=true;
			 this->pic3->Visible=true;
			 this->list3->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 break;
			 case 4:
			 this->lblRes4->Visible=true;
			 this->lblDir4->Visible=true;
			 this->pic4->Visible=true;
			 this->list4->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
				 break;
			 case 5:
			 this->lblRes5->Visible=true;
			 this->lblDir5->Visible=true;
			 this->pic5->Visible=true;
			 this->list5->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
				 break;
				 }
				  evento--;
				 }
			 }
		 }
private: System::Void btnMostrar_Click(System::Object^  sender, System::EventArgs^  e) {
			   if(colita.Cola_vacia()==true)
			   {
				 infor.Set_nombre("021 Hall Resto Bar");
				 infor.Set_direccion("Av. Alemana 3er. Anillo externo esquina Av. Japon 0591");
				 infor.Set_mesas(9);
			     colita.Insertar(infor);
				 infor.Set_nombre("Jardin de Asia");
			     infor.Set_direccion("Av Marcelo Terceros B�nzer, Santa Cruz de la Sierra");
				 infor.Set_mesas(25);
			     colita.Insertar(infor);
				 infor.Set_nombre("Michelangelo");
			     infor.Set_direccion("Calle Chuquisaca esq. Manuel Ignacio Salvatierra No. 502");
				 infor.Set_mesas(13);
			     colita.Insertar(infor);
				 infor.Set_nombre("Angelino");
			     infor.Set_direccion("Boulevard del Ventura Mall");
				 infor.Set_mesas(15);
			     colita.Insertar(infor);
				 infor.Set_nombre("Factory");
			     infor.Set_direccion("Av. Velarde esquina Juan de Garay Nro. 300");
				 infor.Set_mesas(20);
			     colita.Insertar(infor);
			   }
			  
		 
		     colita.Guardar_cola_grilla(grillaRestaurant);

		 
		 }
private: System::Void btnOpcion_Click(System::Object^  sender, System::EventArgs^  e) {
			 int cant;
			 if((txtCantidad->Text)!=""){
				 cant=System::Convert::ToInt32(txtCantidad->Text);}
			 else
			 {cant=0;
			 }
			 opc=System::Convert::ToInt32(txtOpcion->Text);
			 if(opc>5 || opc<1)
			 {MessageBox::Show("OPCION INEXISTENTE");
			 }
			 else{
				  MessageBox::Show("Debido al COVID-19 la cantidad de mesas en los Restaurantes han sido reducidas a la mitad");
				 this->grillaRestaurant->Visible=false;
				 this->btnMostrar->Visible=false;
				 this->lblOpcion->Visible=false;
				 this->btnOpcion->Visible=false;
				 this->txtOpcion->Visible=false;
				 this->btnAtras->Visible=true;
				  switch(opc)
			 {case 1:
			 this->lblRes1->Visible=true;
			 this->lblDir1->Visible=true;
			 this->pic1->Visible=true;
			 this->lblmen->Visible=true;
			 this->list1->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
			 break;
			 case 2:
			 this->lblRes2->Visible=true;
			 this->lblDir2->Visible=true;
			 this->pic2->Visible=true;
			 this->list2->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
			 break;
			 case 3:
			 this->lblRes3->Visible=true;
			 this->lblDir3->Visible=true;
			 this->pic3->Visible=true;
			 this->list3->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
			 break;
			 case 4:
			 this->lblRes4->Visible=true;
			 this->lblDir4->Visible=true;
			 this->pic4->Visible=true;
			 this->list4->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
				 break;
			 case 5:
			 this->lblRes5->Visible=true;
			 this->lblDir5->Visible=true;
			 this->pic5->Visible=true;
			 this->list5->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
				 break;

			 }
			 }
			 evento++;
		 }
private: System::Void btnReservar_Click(System::Object^  sender, System::EventArgs^  e) {
			 this->lblRes1->Visible=false;
			 this->lblDir1->Visible=false;
			 this->pic1->Visible=false;
			 this->list1->Visible=false;
			 this->lblRes2->Visible=false;
			 this->lblDir2->Visible=false;
			 this->pic2->Visible=false;
			 this->list2->Visible=false;
			 this->lblRes3->Visible=false;
			 this->lblDir3->Visible=false;
			 this->pic3->Visible=false;
			 this->list3->Visible=false;
			 this->lblRes4->Visible=false;
			 this->lblDir4->Visible=false;
			 this->pic4->Visible=false;
			 this->list4->Visible=false;
			 this->lblRes5->Visible=false;
			 this->lblDir5->Visible=false;
			 this->pic5->Visible=false;
			 this->list5->Visible=false;
			 this->lblmen->Visible=false;
			 this->lblmesas->Visible=false;
			 this->txtmesas->Visible=false;
			 this->lblpregunta->Visible=false;
			 this->txtCantidad->Visible=false;
			 this->btnReservar->Visible=false;
			 this->cmbDia->Visible=true;
			 this->cmbHora->Visible=true;
             this->lblDia->Visible=true;
			 this->lblHora->Visible=true;
			 this->btnCompletar->Visible=true;
	evento++;

		 }
private: System::Void btnRegistrar_Click(System::Object^  sender, System::EventArgs^  e) {
			     this->lblJalf->Visible=false;
				 this->btnIngresar->Visible=false;
				 this->txtUsuario->Visible=false;
				 this->txtContra->Visible=false;
				 this->btnRegistrar->Visible=false;
				//elementos para registrar
				 this->lblTelefono->Visible=true;
				 this->txtRegis->Visible=true;
				 this->txtTelefono->Visible=true;
				 this->txtRegiscont->Visible=true;
				 this->btnRegis->Visible=true;
		 }
private: System::Void btnRegis_Click(System::Object^  sender, System::EventArgs^  e) {
			  int j;
			  j=0;

			  if(txtRegis->Text!="")
			  {regis.Set_nomus(marshal_as<std::string>(System::Convert::ToString(txtRegis->Text)));
				  j++;
			  }
			  if(txtRegiscont->Text!="")
			  {regis.Set_contra(marshal_as<std::string>(System::Convert::ToString(txtRegiscont->Text)));
				  j++;
			  }
			  if(txtTelefono->Text!="")
			  {regis.Set_telefono(System::Convert::ToInt32(txtTelefono->Text));
			   j++;
			  }

			 if(j<3)
			  {MessageBox::Show("Falta Ingresar algun dato");
			  }
			  else
			  {MessageBox::Show("Registro Exitoso");
			  	 this->lblTelefono->Visible=false;
				 this->txtRegis->Visible=false;
				 this->txtTelefono->Visible=false;
				 this->txtRegiscont->Visible=false;
				 this->btnRegis->Visible=false;
			     this->lblJalf->Visible=true;
				 this->btnIngresar->Visible=true;
				 this->txtUsuario->Visible=true;
				 this->txtContra->Visible=true;
				 this->btnRegistrar->Visible=true;
				 regis.Set_codigo(codigo);
				 ofstream fsalida(USUARITO, ios::app | ios::binary);	
				 regis.guardarArchivo(fsalida);
				 fsalida.close();
				 codigo++;
			 }

		 }
private: System::Void btnCompletar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int cant;
			 string hora;
			 string dia;
			 cant=System::Convert::ToInt32(txtCantidad->Text);
			 hora=marshal_as<std::string>(System::Convert::ToString(cmbHora->Text));
			 dia=marshal_as<std::string>(System::Convert::ToString(cmbDia->Text));
			 if(colita.Calcularmes(opc,cant)>=0)
			 {

			 MessageBox::Show(marshal_as<System::String^>("Reserva completada el dia "+dia+ " a las "+hora));
			 this->cmbDia->Visible=false;
			 this->cmbHora->Visible=false;
             this->lblDia->Visible=false;
			 this->lblHora->Visible=false;
			 this->btnCompletar->Visible=false;
			 evento--;
			 switch(opc)
			 {case 1:
			 this->lblRes1->Visible=true;
			 this->lblDir1->Visible=true;
			 this->pic1->Visible=true;
			 this->lblmen->Visible=true;
			 this->list1->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
			 break;
			 case 2:
			 this->lblRes2->Visible=true;
			 this->lblDir2->Visible=true;
			 this->pic2->Visible=true;
			 this->list2->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
			 break;
			 case 3:
			 this->lblRes3->Visible=true;
			 this->lblDir3->Visible=true;
			 this->pic3->Visible=true;
			 this->list3->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
			 break;
			 case 4:
			 this->lblRes4->Visible=true;
			 this->lblDir4->Visible=true;
			 this->pic4->Visible=true;
			 this->list4->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
				 break;
			 case 5:
			 this->lblRes5->Visible=true;
			 this->lblDir5->Visible=true;
			 this->pic5->Visible=true;
			 this->list5->Visible=true;
			 this->lblmen->Visible=true;
			 this->lblmesas->Visible=true;
			 this->txtmesas->Visible=true;
			 this->lblpregunta->Visible=true;
			 this->txtCantidad->Visible=true;
			 this->btnReservar->Visible=true;
			 txtmesas->Text=System::Convert::ToString(colita.Calcularmes(opc,cant));
				 break;

			 }
			 }
			 else
			 {MessageBox::Show("NO HAY ESPACIO SUFICIENTE \n Lo sentimos");
			 }

		 }
private: System::Void txtRegiscont_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

