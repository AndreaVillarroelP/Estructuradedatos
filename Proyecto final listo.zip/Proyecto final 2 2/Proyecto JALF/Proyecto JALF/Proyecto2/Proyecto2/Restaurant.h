#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;
using namespace msclr::interop;
class Restaurant
{string nombre;
string direccion;
int mesas;
public:
	Restaurant(void);
	string Get_nombre();
	string Get_direccion();
	int Get_mesas();
    void Set_nombre(string nom);
	void Set_direccion(string dir);
	void Set_mesas(int mes);

};

