#include "StdAfx.h"
#include "Usuario.h"
#include <fstream>

Usuario::Usuario(void)
{nomus="";
 contra="";
 telefono=0;
 estado='A';
 codigo=0;
}
string Usuario::Get_nomus()
{
	return nomus;
}
string Usuario::Get_contra()
{
	return contra;
}
void Usuario::Set_nomus(string nom)
{
	nomus=nom;
}
void Usuario::Set_contra(string conti)
{
	contra=conti;
}
int Usuario::Get_tel()
{
	return telefono;
}
void Usuario::Set_telefono(int tel)
{
	telefono=tel;
}
int Usuario::Get_codigo()
{
	return codigo;
}
void Usuario::Set_codigo(int cod)
{
	codigo=cod;
}
char Usuario::Get_estado()
{
	return estado;
}
void Usuario::Set_estado(char est)
{
	estado=est;
}
void Usuario::guardarArchivo(ofstream &fsalida) {
		fsalida.write(reinterpret_cast<char *>(&nomus), sizeof(nomus));
		fsalida.write(reinterpret_cast<char *>(&contra), sizeof(contra));
		fsalida.write(reinterpret_cast<char *>(&telefono), sizeof(telefono));
		fsalida.write(reinterpret_cast<char *>(&estado), sizeof(estado));
		fsalida.write(reinterpret_cast<char *>(&codigo), sizeof(codigo));
	}

bool Usuario::leerArchivo(ifstream &fentrada) {
		bool k = false;
		if (fentrada.is_open() == true) {
			fentrada.read(reinterpret_cast<char *>(&nomus), sizeof(nomus));
			if (fentrada.eof() == false) {				
				fentrada.read(reinterpret_cast<char *>(&contra), sizeof(contra));
				fentrada.read(reinterpret_cast<char *>(&telefono), sizeof(telefono));
				fentrada.read(reinterpret_cast<char *>(&estado), sizeof(estado));
				fentrada.read(reinterpret_cast<char *>(&codigo), sizeof(codigo));
				k = true;
			}
		}
		return(k);
	}
	int Usuario::getTamBytesRegistro() {
		return(sizeof(nomus) + sizeof(contra) + sizeof(telefono) + sizeof(estado)+sizeof(codigo));
	}

