#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "Cola.h"
using namespace System::Windows::Forms;
using namespace std;
using namespace msclr::interop;
class Operaciones: public Cola
{
public:
	Operaciones(void);
	void Guardar_cola_grilla(DataGridView^  grilla_cola);
	int Calcularmes(int opc,int cant);
	int Longitud_cola();
};

