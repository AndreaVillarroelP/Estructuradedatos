#include "StdAfx.h"
#include "Restaurant.h"
#include <fstream>

Restaurant::Restaurant(void)
{nombre="";
 direccion="";
 mesas=0;
}
string Restaurant::Get_nombre()
{
	return nombre;
}
string Restaurant::Get_direccion()
{
	return direccion;
}
int Restaurant::Get_mesas()
{
	return mesas;
}
void Restaurant::Set_nombre(string nom)
{
	nombre=nom;
}
void Restaurant::Set_direccion(string dir)
{
	direccion=dir;
}
void Restaurant::Set_mesas(int mes)
{
	mesas=mes;
}


