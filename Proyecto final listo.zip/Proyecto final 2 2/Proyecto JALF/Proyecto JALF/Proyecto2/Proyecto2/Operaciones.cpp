#include "StdAfx.h"
#include "Operaciones.h"


Operaciones::Operaciones(void)
{
Cola();
}
void Operaciones::Guardar_cola_grilla(DataGridView^  grilla_cola)
{
	int i,n=1;
	Restaurant nodito;
	i=0;
	Cola aux;
	aux=This_cola();
	grilla_cola->ColumnCount=3;
	grilla_cola->RowCount=Longitud_cola();
	while(aux.Cola_vacia()==false)
	{
	
		aux.Eliminar(nodito);
		grilla_cola->Rows[i]->Cells[0]->Value=System::Convert::ToString(n);
		grilla_cola->Rows[i]->Cells[1]->Value=marshal_as<System::String^>(nodito.Get_nombre());
		grilla_cola->Rows[i]->Cells[2]->Value=marshal_as<System::String^>(nodito.Get_direccion());
		n++;
	    i++;
	}
}



int Operaciones::Longitud_cola()
{
	int t=0;
	Cola aux;
	aux=This_cola();
	Restaurant nodito;
	while(aux.Cola_vacia()==false)
	{
	
	  aux.Eliminar(nodito);
	  t++;
	}
   return t;
}
int Operaciones::Calcularmes(int opc,int cant)
{int i,mes,mesn;
    Restaurant nodito;
	i=0;
	Cola aux;
	aux=This_cola();
	while(i!=(opc))
	{aux.Eliminar(nodito);
	    if(i==opc-1)
		{if(cant%5!=0)
		{mes=(cant/5)+1;
		}
		else
		{
		  mes=cant/5;
		}
		  mesn=nodito.Get_mesas()-mes;
		  nodito.Set_mesas(mesn);
		  if(nodito.Get_mesas()<0)
		  {return (-1);
		  }
		  else
		  {return nodito.Get_mesas();
		  }

	    }
		i++;
}
	
}
