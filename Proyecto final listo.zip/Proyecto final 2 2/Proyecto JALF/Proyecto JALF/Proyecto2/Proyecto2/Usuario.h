#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include <fstream>
using namespace std;
using namespace msclr::interop;
class Usuario
{string nomus;
 string contra;
 int telefono;
 char estado;
 int codigo;
public:
	Usuario(void);
	string Get_nomus();
	string Get_contra();
	int Get_tel();
    void Set_nomus(string nom);
	void Set_telefono(int tel);
	void Set_contra(string conti);
	int Get_codigo();
    void Set_codigo(int cod);
	char Get_estado();
    void Set_estado(char est);
	//manejo de archivos
	void guardarArchivo(ofstream &fsalida);
	bool leerArchivo(ifstream &fentrada);
	int getTamBytesRegistro(); 
};

