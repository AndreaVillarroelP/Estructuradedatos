#pragma once

#include <string>
using namespace std;

class Cuenta
{
private: 
	//Atributos
	double TipoDeInteres;
    double saldo;
    string cuenta;
    string nombre;
	double Estado;

public:
	Cuenta(void);//constructor
	Cuenta(string nom,string cue,double sal, double tipo);
	virtual ~Cuenta(void);//destructor
	void set_Nombre(string nom);
	void set_Cuenta(string cue);
	string get_Nombre();
	string get_Cuenta();
	double get_TipoDeInteres();
	double estado();
	double get_Saldo();
	void set_TipoDeInteres(double tipo);
	void reintegro(double cantidad);
	void ingreso(double cantidad);
};

