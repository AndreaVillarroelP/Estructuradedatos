#include "StdAfx.h"
#include "Cuenta.h" //Declarar el Header(cabecera) de la clase
#include <iostream>
#include <string>

Cuenta::Cuenta(void)
{saldo=0;
 TipoDeInteres=0.0;
}
Cuenta::Cuenta(string nom,string cue,double sal, double tipo)
{
	nombre=nom;
	cuenta=cue;
	saldo=sal;
	TipoDeInteres=tipo;
}

Cuenta::~Cuenta(void)
{
}
void Cuenta::set_Nombre(string nom)
{if(nom.length()==0)
{//cout<<"Error: Cadena vacia"<<endl;
}
nombre=nom;
}
void Cuenta::set_Cuenta(string cue)	
{
	cuenta=cue;
}
string Cuenta::get_Nombre()
{
	return nombre;
}
string Cuenta::get_Cuenta()
{
	return cuenta;
}
double Cuenta::get_TipoDeInteres()
{ 
	return TipoDeInteres;
}
double Cuenta::estado()
{
	return saldo;
}
void Cuenta::set_TipoDeInteres(double tipo)
{
	TipoDeInteres=tipo;
}
void Cuenta::reintegro(double cantidad)
{if(saldo-cantidad<0)
 {//cout<<"Error: no dispone de saldo"<<endl;
 }
 else
 {
  saldo=saldo-cantidad;
 }
}
void Cuenta::ingreso(double cantidad)
{if(cantidad<0)
  {//cout<<"Error:Cantidad negativa"<<endl;
  }
 else
 {
  saldo=saldo+cantidad;
 }
}
double Cuenta::get_Saldo()
{
	return saldo;
}
